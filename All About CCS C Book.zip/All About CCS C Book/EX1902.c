/*--------------------------------------------------------
File      : EX1902.c
Purpose   : I2C PCF8574A I/O
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // oscillator
#use I2C(master,sda=PIN_C4,scl=PIN_C3)  // I2C Bus module


//-------------------------------------------------------:CONSTANTS
// 01110000, PCF8574A:000 Slave Address (bit1-bit3)
#define PCF8574A_ID  0x70  

//-------------------------------------------------------:PCF8574A Write
void PCF8574A_Write(unsigned int dat) 
{
  i2c_start();              // Send I2C Start Transfer
  i2c_write(PCF8574A_ID);   // Send identifier I2C address - Write
  i2c_write(dat);           // Send data
  i2c_stop();               // Send I2C Stop Transfer
}

//-------------------------------------------------------:PCF8574A Read
unsigned int PCF8574A_Read(void) 
{
  unsigned int idat;

  i2c_start();               // Send I2C Start Transfer
  i2c_write(PCF8574A_ID+1);  // Send identifier I2C address - Read
  idat = i2c_read(0);        // Read data , Not ACK
  i2c_stop();                // Send I2C Stop Transfer
  delay_ms(200);
  return(idat);
}

//-------------------------------------------------------:MAIN
void main(void) {
  unsigned int idat;
   
  for(idat = 0; idat<10; idat++)
  {
    PCF8574A_Write(0x0A);  
    delay_ms(100);
    PCF8574A_Write(0x05);  
    delay_ms(100);
  }    

  while(TRUE) {
    idat = PCF8574A_Read();   // Read data
    idat = idat>>4;           // Shift to Nibble Low
    idat = idat|0xF0;         // Mark bit Nibble High
    PCF8574A_Write(idat);     // Out data
  }
}
