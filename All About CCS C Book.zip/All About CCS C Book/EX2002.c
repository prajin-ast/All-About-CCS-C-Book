/*--------------------------------------------------------
File      : EX2002.c
Purpose   : Write/Read FLASH
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

#include <stdio.h>

//-------------------------------------------------------:MAIN
void main(void) {
  unsigned int16 i, address;
  unsigned char ch;
  
  address = 0x1000;   // Start Program Memory address
  
  printf("\f\r\nWrite/Read FLASH demo..");
  
  do {
    printf("\r\nPls input character or number : ");
    ch = getch();
    putc(ch);
    printf("  [Press 'z' to Exit]");
    write_program_eeprom(address++,ch);
  } while(ch != 'z');
  
  for(i=0x1000; i<address; i++) {
    ch = read_program_eeprom(i);
    printf("\r\nFLASH Address[%lX] : ASCII: %c, Hex: %u", i, ch, ch);
  }
  
  while(1);   // Loop nothing
}
