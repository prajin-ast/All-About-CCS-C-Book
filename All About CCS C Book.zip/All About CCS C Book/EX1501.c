/*--------------------------------------------------------
File      : EX1501.c
Purpose   : RS232 I/O Control
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>          // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:LED Control
void LedControl(unsigned int led) 
{
  unsigned int led_tmp=0;
  
  led_tmp = (1<<led);  // High LED
  output_d(led_tmp);   // output
}

//-------------------------------------------------------:MAIN
void main(void) {
  int i;
  char digit;

  set_tris_d(0x00);     // PORTB output
  set_tris_a(0x00);     // PORTA output
  output_d(0x00);       // clear led

  while(TRUE) {
    printf("\n\rInput 0-7 Number LED : ");
    digit = getc();        
    putc(digit);
    output_toggle(PIN_A0);
    if(digit<'8') {
      i= digit-'0';
      LedControl(i);
    } else {
      puts(" (Invalid Number)");
    }
  }
}
