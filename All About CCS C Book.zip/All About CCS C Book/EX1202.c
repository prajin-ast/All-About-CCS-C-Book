/*--------------------------------------------------------
File      : EX1202.c
Purpose   : Test Debugger
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877.h>          // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:add_num
float add_num(float i, float j) {

  return(i + j);        // return function
}

//-------------------------------------------------------:MAIN
void main(void) {
  float i, j;            // Declarations
  float anum=0;          // Definitions

  i = 5.4;
  j = 4.6;
  anum = add_num(i,j);  // call add_num()

  while(TRUE);          // loop nothing
}
