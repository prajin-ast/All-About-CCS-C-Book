/*--------------------------------------------------------
File      : EX1103.c
Purpose   : Rotate_left function
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:MAIN
void main(void) {
   int i=0x01;
   
   set_tris_d(0x00);    // Set PORTD all output
   while(TRUE) {         
      output_d(i);
      delay_ms(500);
      rotate_left( &i, 1);
   }
}
