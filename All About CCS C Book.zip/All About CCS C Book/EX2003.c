/*--------------------------------------------------------
File      : EX2003.c
Purpose   : Write/Read FLASH
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#fuses WRT_25%
#use delay(clock=20000000)        // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

#include <stdio.h>


//-------------------------------------------------------:MAIN
void main(void) {
  unsigned int16 address;
  unsigned char i, ch, count;
  
  int16 wbuffer[21]= "";
  int16 rbuffer[21]= "";
    
  address = 0x1000;   // Start Program Memory address
  count = 0;          // Count start
  
  printf("\f\r\nWrite/Read FLASH 20 Character Demo..");
  do {
    printf("\n\rPls input character/number : ");
    ch = getch();
    putc(ch);
    wbuffer[count++] = ch;
    printf("   [Press 'z' to Exit]");
  } while(ch != 'z' && count<21);

  // Write data from wbuffer to Program Memory address 0x1000
  write_program_memory(0x1000, wbuffer, 1);
  
  // Read data from Program Memory address 0x1000 to rbuffer
  read_program_memory(0x1000, rbuffer, 20);
  
  printf("\n\rFLASH Data %d Character",count);
  for(i=0; i<count; i++) {    
    ch = rbuffer[i];
    printf("\n\rFLASH rbuffer[%u]: ASCII: %c, Hex: %u", i, ch, ch);
  }

  while(1);   // Loop nothing
}
