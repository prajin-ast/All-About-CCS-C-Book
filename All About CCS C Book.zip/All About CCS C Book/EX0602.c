/*--------------------------------------------------------
File      : EX0602.c
Purpose   : while loop example
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:MAIN
void main(void) {
   int32 i=0;
   char ch;
   
   printf("Press key q for exit\n\r");
   ch = getch();
   
   while(ch !='q') {
      i++;
      ch = getch();
   }
   
   printf("Got a q! number of type %d\n\r",i);
   
   while(TRUE);
}
