/*--------------------------------------------------------
File      : EX0404_main.c
Purpose   : Main program
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

#include "EX0403_sub.c"    // use function createExobject()

//-------------------------------------------------------:Global variables
int ExtObjectID;

//-------------------------------------------------------:Func: createObject
int createObject() {
   static int i=0;

   i = i + 1;
   return(i);
}

//-------------------------------------------------------:MAIN
void main() 
{
   int k,id;

   for(k=0;k<5;k++) {
      id = createObject();
      printf("In createObject() i = %d\n\r",id);
      printf("In createExtObject() id = %d\n\r",createExtObject());
      printf("In createExtObject() ExtObjectID = %d\n\r",ExtObjectID);
      id = id + ExtObjectID;
      printf("function Main id = %d\n\r\n",id);
   }
   while(1);   // loop nothing
}
