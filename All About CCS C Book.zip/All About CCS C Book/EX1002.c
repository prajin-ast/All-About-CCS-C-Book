/*--------------------------------------------------------
File      : EX1002.c
Purpose   : Union Examples
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:Union
union IntOrFloat {
    int8 i;      
    int16 l;    
}a_number;

//-------------------------------------------------------:MAIN
void main(void) {

    a_number.i = 20000;
    printf("a_number.i: %d\n",a_number.i);

    a_number.l = 2000000;
    printf("a_number.l: %ld\n",a_number.l);

  while(TRUE);
}
