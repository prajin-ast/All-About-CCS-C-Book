/*--------------------------------------------------------
File      : EX1602.c
Purpose   : Output Compare (CCP1)
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>          // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

#byte TRIS_C = 0x87           // TRISC File Address
#bit  RC2    = TRIS_C.2       // TRISC.2 bit address

//-------------------------------------------------------:CCP1 Interrupt
#INT_CCP1
void CCP1_isr() {
  static int cpp_count = 0;
    
  printf("\r\nCCP1 On Match TMR1: %lu",get_timer1());
  output_toggle(PIN_A0);
  if (cpp_count++ > 10) 
  {
      printf("\fCompare Mode");       // Clear screen & print
      cpp_count = 0;
  }      
}

//-------------------------------------------------------:MAIN
void main(void) {
  
  set_tris_a(0x00);     // Set output
  RC2 = 0;              // Set output
  output_low(PIN_C2);   // Clear RC2
  delay_ms(1000);       // Delay 1s
  
  enable_interrupts(INT_CCP1);    // Enable interrupt CCP1
  enable_interrupts(GLOBAL);      // All interrupts ON

  setup_ccp1(CCP_COMPARE_SET_ON_MATCH);   // Configure CCP1 set on match
  CCP_1 = 0x00FF;                 // Set CCPR1 Register
  
  setup_timer_1(T1_INTERNAL|T1_DIV_BY_8);   // Setup timer1
  set_timer1(0);                            // Start timer

  printf("\fCompare Mode");       // Clear screen & print
  
  while(TRUE);          // Loop nothing
  
}
