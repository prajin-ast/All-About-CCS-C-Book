/*--------------------------------------------------------
File      : EX1403.c
Purpose   : Pulse-width modulation example
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

#define SW1   PIN_A0    // Switch

int int_count = 0;      // Number of interrupts left before a second has elapsed

//-------------------------------------------------------:Timer2 Interrupt
#INT_TIMER2
void t2_isr() {
  int_count = 0;
}

//-------------------------------------------------------:MAIN
void main() {
   char selection;
   unsigned int value;
   
  enable_interrupts(GLOBAL);
  enable_interrupts(INT_TIMER2);

  printf("\f\rFrequency:");
  printf("\r\n 1) 39.06 khz");
  printf("\r\n 2) 9.76 khz");
  printf("\r\n 3) 2.44 khz");
  printf("\r\nSelection >> ");
  do {
     selection=getc();
  } while((selection<'1')||(selection>'3'));

  setup_ccp1(CCP_PWM);   // Configure CCP1/RC2 as a PWM

  // The cycle time will be (1/clock)*4*t2div*(period+1)
  // In this program clock=10000000 and period=127 (below)
  // For the three possible selections the cycle time is:
  //  (1/20000000)*4*1*128 =  25.6 us or 39.06 khz
  //  (1/20000000)*4*4*128 = 102.4 us or 9.76 khz
  //  (1/20000000)*4*16*128= 409.6 us or 2.44 khz

  switch(selection) {
    case '1' : 
      setup_timer_2(T2_DIV_BY_1, 127, 1);
      break;
    case '2' : 
      setup_timer_2(T2_DIV_BY_4, 127, 1);
      break;
    case '3' : 
      setup_timer_2(T2_DIV_BY_16, 127, 1);
      break;
   }

  value = 1;
  set_pwm1_duty(value);
  printf("\r\nSW1 Press (Change Duty)");
  printf("\r\nDuty :%u",value);

  while( TRUE ) {
    if(input(SW1) == 0) {
      value++;
      delay_ms(100);
      printf("\r\nSW1 Press (Change Duty)");
      printf("\r\nDuty :%u",value);
      set_pwm1_duty(value);
    }      
  }
}
