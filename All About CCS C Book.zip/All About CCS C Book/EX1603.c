/*--------------------------------------------------------
File      : EX1603.c
Purpose   : PWM (CCP1)
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

#define SW1   PIN_A0      // Switch

//-------------------------------------------------------:MAIN
void main() {
  unsigned int duty, value=0;
  BOOLEAN updw;

  // Set port output for Compare Mode
  set_tris_c(0x00);         // port C output all
   
  // Setup CCP Module
  setup_ccp1(CCP_PWM);

  // Setup Timer2
  // Prx = 255, TMRx Prescale = 16
  // period = [(Prx) + 1] * Tcy * (TMRx Prescale)
  //        = [(255)+1] * [1/(20MHz/4)] * 16
  //        = 819.2 us
  // Fpwm   = 1.2 kHz
  setup_timer_2(T2_DIV_BY_16, 255, 1);     
  set_timer2(0);
  
  // the following sets the duty to 50%
  // value = (duty/100) * (Prx+1)
  // Duty 100% = 256
  // Duty 50%  = (50/100)* 256
  set_pwm1_duty(128);
  
  printf("\f\rPWM frequency: 1.22 khz Duty cycle 50%%");
  printf("\r\nSW1 Press (Change Duty)");
  printf("\r\nDuty : 50%%");

  while( TRUE ) {
    if(input(SW1) == 0) {
      duty = (value/100.0)* 256;
      set_pwm1_duty(duty);
      delay_ms(100);
    
      if (value == 0) updw = 1;
      if (value == 100) updw = 0;    
    
      if (updw) 
        value++;
      else       
        value--;    
        
      printf("\r\nSW1 Press (Change Duty)");
      printf("\r\nDuty :%u%%",value);
    }      
  }
}
