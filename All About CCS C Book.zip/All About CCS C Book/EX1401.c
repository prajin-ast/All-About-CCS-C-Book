/*--------------------------------------------------------
File      : EX1401.c
Purpose   : Find Time for 2 Keypress
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>          // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

int16 seconds = 0;      // A running seconds counter
int int_count = 0;      // Number of interrupts left before a second has elapsed

//-------------------------------------------------------:Timer0 Interrupt
// This function is called every time the RTCC (timer0) overflows (255->0).
// For this program this is apx 76 times per second.
#INT_TIMER0                         
void clock_isr() {                                                    
    if(int_count++ >76) {           
      ++seconds;
      int_count = 0;
    }
}

//-------------------------------------------------------:MAIN
void main() {
   int16 start;
   
   enable_interrupts(GLOBAL);
   enable_interrupts(INT_TIMER0);

   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_256);
   set_timer0(0);

   do {
      printf("Press any key to begin.\n\r");
      getc();
      start=seconds;
      printf("Press any key to stop.\n\r");
      getc();
      printf("Key press time: %lu seconds.\n\r",seconds-start);

   } while (TRUE);
}
