/*--------------------------------------------------------
File      : EX1201.c
Purpose   : 2 FLASH LED
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator

//-------------------------------------------------------:MAIN
void main(void)
{  
  setup_adc(ADC_OFF);    // OFF ADC
  set_tris_a(0x00);     // Set PORTA for output    
  
  while(TRUE) {
    output_low(PIN_A0);
    output_high(PIN_A1);
    delay_ms(1);
    output_high(PIN_A0);
    output_low(PIN_A1);
    delay_ms(1);
  }
}
