/*--------------------------------------------------------
File      : EX1102.c
Purpose   : Shift Function
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:MAIN
void main(void) {
   int1 ibit;
   int x[3] = {0b10010001, 0b00011100, 0b10000001 };

   ibit = shift_left(x,sizeof(x),0);
   printf("%d",ibit);
   ibit = shift_right(x,sizeof(x),1);
   printf("%d",ibit);
   
   while(1);         // Loop nothing
}
