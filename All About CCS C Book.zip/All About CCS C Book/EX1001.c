/*--------------------------------------------------------
File      : EX1001.c
Purpose   : Structures Examples
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:Structures
struct str_idname {
    int id;
    char name[20];
} sname, *ptrSname;

//-------------------------------------------------------:MAIN
void main(void) {

    ptrSname = &sname;
    sname.id = 1000;

    ptrSname->id = 1000;
    strcpy(ptrSname->name,"Mr Pointer to Structures");

    printf("sname.id : %d\n",sname.id);
    printf("ptrSname->id : %d\n",ptrSname->id);
    printf("%s\n",ptrSname->name);
    
    while(TRUE);
}
