/*--------------------------------------------------------
File      : EX0402.c
Purpose   : Enum Variables
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:MAIN
void main(void) 
{
   enum ANS { NO, YES};   
   ANS i;
   
   i = YES;           // or i = 1;
   if(i == YES) {
      printf("Yes\n\r");
   } else {
      printf("No\n\r");
   }
   
   while(TRUE);
} 



