/*--------------------------------------------------------
File      : EX1301.c
Purpose   : RB0/INT External Interrupt
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877.h>          // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator

int1 c_bit = 1;

//-------------------------------------------------------:External Interrupt
#INT_EXT
void IntExt_isr(void) {
   output_high(PIN_A0);
   delay_ms(100);      
   output_low(PIN_A0);
   c_bit = !c_bit;                  // toggle bit
}

//-------------------------------------------------------:MAIN
void main(void) {
   int dat = 0x01;                  // data for rotate
   
   set_tris_a(0x00);                // Set PORTA output
   output_low(PIN_A0);              // Low pin RA0
   
   enable_interrupts(GLOBAL);       // Enable Glabal Interrupt 
   enable_interrupts(INT_EXT);      // Enable External Interrupt
   ext_int_edge(H_TO_L);            // Set Interrupt Edge High to Low
   
   while(TRUE) {                    // loop forever
      if (c_bit)                    // change control
         rotate_left(&dat, 1);         
      else
         rotate_right(&dat,1);
      
      output_d(dat);
      delay_ms(250);      
   }
}
