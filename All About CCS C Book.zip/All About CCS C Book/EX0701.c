/*--------------------------------------------------------
File      : EX0701.c
Purpose   : One-Dimensional Arrays example
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:MAIN
void main(void) {
   int i, num[10];

   for(i=0; i<10; i++)
    num[i] = i;
   for(i=0; i<10; i++)
      printf("i[%d] = %d  ", i , num[i]);
   
   while(TRUE);
}
