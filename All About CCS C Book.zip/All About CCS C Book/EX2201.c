/*--------------------------------------------------------
File      : EX2201.c
Purpose   : Drive LED 7 Segment Using PORTB
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // oscillator

#define LED_DSP(x)   OUTPUT_D(x)

//-------------------------------------------------------:GLOBAL VARIABLES
char dt1,dt2;         // delay time

// 0x77, 0x39, 0x79 => A,C,E
// 0x71, 0x74, 0x5C => F,H,O
// 0x73, 0x6D, 0x78 => P,S,T
char const LED_CHR[17] ={ 0x77, 0x73, 0x73,         // APP
                          0x6D, 0x5C, 0x71, 0x78,   // SOFT
                          0x78, 0x79, 0x39, 0x74,   // TECH
                          0x00, 0x00, 0x00,         // bank, bank, bank
                          0x77,0x6D,0x78            // AST
                        };

char const LED_NUM[17] = {0x3F, 0x06, 0x5B, 0x4F, 0x66,  //0,1,2,3,4
                          0x6D, 0x7D, 0x07, 0x7F, 0x6F,  //5,6,7,8,9
                          0x77, 0x7C, 0x39, 0x5E, 0x79,  //A,b,C,d,E
                          0x71, 0x80,                    //F,.
                         };                         

//-------------------------------------------------------:Dispaly Digit1
void dsp_digit1(char n) {
  output_a(0x06);
  LED_DSP(n);
  delay_ms(3-dt1-dt2);   // delay
}

//-------------------------------------------------------:Dispaly Digit1
void dsp_digit2(char n) {
  output_a(0x05);
  LED_DSP(n);
  delay_ms(dt1);        // delay
}

//-------------------------------------------------------:Dispaly Digit1
void dsp_digit3(char n) {
  output_a(0x03);
  LED_DSP(n);
  delay_ms(dt2);        // delay
}

//-------------------------------------------------------:MAIN
void main(void) {
  unsigned int16 i,j;
  unsigned int cc;

  set_tris_a(0x00);     // PORTA output
  set_tris_d(0x00);     // PORTD output

  dt1 = 1;             // Delay time
  dt2 = 1;

  while(TRUE) {
    // Display APPSOFTTECH
    for(i=0; i<14; i++) {
      for(j=0; j<200; j++) {    // for display loop
        dsp_digit1(LED_CHR[i]);
        if(i>0) dsp_digit2(LED_CHR[i-1]);
        if(i>1) dsp_digit3(LED_CHR[i-2]);
      }
      // Display AST
      if(i==13) {
        for(j=0; j<5; j++) {
          for(cc=0; cc<200; cc++) {
            dsp_digit1(LED_CHR[16]|LED_NUM[16]);  // Or dot dp
            dsp_digit2(LED_CHR[15]);
            dsp_digit3(LED_CHR[14]);
          }
          output_high(PIN_A2);    // disable digit3
          delay_ms(500);          // delay
        }
      }
    }
    // Display Countdown number 999 to 0 
    for(i=999; i>0; i--) {
      for(j=0; j<10; j++) {    // for display loop
        dsp_digit1(LED_NUM[((i%100)%10)]);      
        dsp_digit2(LED_NUM[((i%100)/10)]);
        dsp_digit3(LED_NUM[(i/100)]);
      }    
    }      
  }
}
