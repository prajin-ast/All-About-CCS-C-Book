/*--------------------------------------------------------
File      : EX1601_1.c
Purpose   : Frequency Capture (CCP1)
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>          // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

#byte TRIS_C = 0x87           // TRISC File Address
#bit  RC2    = TRIS_C.2       // TRISC.2 bit address

unsigned int16 CCP_Count = 0;
unsigned int tick = 0;
BOOLEAN sec = 0;

//-------------------------------------------------------:CCP1 Interrupt
#INT_CCP1
void CCP1_isr() {

  CCP_Count++;
}

#INT_TIMER1
void TIMER1_isr()
{
  if (tick++ >=20) {
    sec = 1;
    tick = 0;
  }    
}

//-------------------------------------------------------:MAIN
void main(void) {  

  RC2 = 1;              // Set CCP1/RC2 input  
  enable_interrupts(INT_CCP1);    // Enable interrupt CCP1
  enable_interrupts(INT_TIMER1);  // Enable interrupt TIMER1
  enable_interrupts(GLOBAL);      // All interrupts ON

  setup_ccp1(CCP_CAPTURE_RE);     // Configure CCP1 to capture Every rising edge
  setup_timer_1(T1_INTERNAL|T1_DIV_BY_4);   // Setup timer1
  set_timer1(0);                            // Start timer

  printf("\fFrequency Capture Mode");     // Clear screen & print
  delay_ms(1000);
  
  while(TRUE) {  
    if (sec) {
      printf("\fFrequency %lu Hz",CCP_Count);
      CCP_Count = 0;
      sec = 0;
    }
  }
}
