/*--------------------------------------------------------
File      : EX0503.c
Purpose   : Conditional Operator
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:MAIN
void main(void) {
   int i, j, k;
   
   i = 20;
   j = 30;
   k = (i > j) ?  i = i - j :  j = j - i;
   printf("i = %d, j = %d, k = %d\n\r",i, j, k);
   
   while(TRUE);
}
