/*--------------------------------------------------------
File      : EX1702.c
Purpose   : Using port A to anolog input port
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#device ADC=10                   // 10bit A/D
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

//-------------------------------------------------------:MAIN
void main(void) {
  int channel = 0;
  int16 value;

  printf("Analog to digital port RA0 :");
  setup_port_a(AN0_AN1_AN2_AN3_AN4);    // A0 A1 A2 A3 A5
  setup_adc(ADC_CLOCK_DIV_16);          // 16Tosc Operation
  printf("\f");                         // Clear screen
  do {
    set_adc_channel(channel);   // Read Analog input # channel
    delay_us(10);               // Delay 10 us wait for change channel
    value = read_adc();
    printf("\r\nADC[%d] : %ld Voltage : %f",channel,value, value*(5.0/1023));
    if (channel++ > 3)
    { channel = 0;
      delay_ms(1000);
      printf("\f");
    }    
  } while (TRUE);
}
