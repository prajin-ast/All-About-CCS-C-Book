/*--------------------------------------------------------
File      : EX2102.c
Purpose   : CCS RTOS Demo (two)
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

// The CCS Real Time Operating System (RTOS) 
// the minor cycle fo all tasks will be 10 microseconds
#use rtos(timer=1,minor_cycle=10us)
//#use rtos(timer=1)

BYTE CONST LED_MAP[17] = {0x3F, 0x06, 0x5B, 0x4F, 0x66,  //0,1,2,3,4
                          0x6D, 0x7D, 0x07, 0x7F, 0x6F,  //5,6,7,8,9
                          0x77, 0x7C, 0x39, 0x5E, 0x79,  //A,b,C,d,E
                          0x71, 0x80};                   //F,.
                          
#define OUT_SEGMENTS  output_d  
int seg_num = 0x01;
char one='1', two = '2', three = '3'; 


//-------------------------------------------------------:TASK 1,2,3
#task(rate=10us,max=10us)
void rtos_task_1 ( )
{
  output_a(~(seg_num));   // Digit active low
  
  switch (seg_num)
  { case 0x01: 
      OUT_SEGMENTS(LED_MAP[one-'0']);   // segs one
      break;
    case 0x02: 
      OUT_SEGMENTS(LED_MAP[two-'0']);   // segs two
      break;
    case 0x04: 
      OUT_SEGMENTS(LED_MAP[three-'0']); // segs three            
      break;
  }  
  seg_num = seg_num << 1;
  if (seg_num == 0x08) seg_num = 0x01;
}

#task(rate=100us,max=10us)
void rtos_task_2 ( )
{
  printf("->Task 2  ");
}

#task(rate=100us,max=10us)
void rtos_task_3 ( )
{  
  printf("->Task 3  ");
}

//-------------------------------------------------------:MAIN
// main is still the entry point for the program
void main ( )
{
  // Set PORTA,PORTD output
  set_tris_a(0);
  set_tris_d(0);
  // Clear port
  output_a(0);
  output_d(0);
  printf("\f\r\n3 Task Demo\n\r");

  // rtos_run begins the loop which will call the task functions above at the
  // schedualed time
  rtos_run ();
}

