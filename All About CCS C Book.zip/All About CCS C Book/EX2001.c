/*--------------------------------------------------------
File      : EX2001.c
Purpose   : Built-in EEPROMS
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

#include <stdio.h>

//-------------------------------------------------------:MAIN
void main(void) {
  unsigned int16 i, address=0;
  unsigned char ch;
  
  printf("\f\r\nBuilt-in EEPROMS demo..");
  
  do {
    printf("\r\nPls input character or number : ");
    ch = getch();
    putc(ch);
    printf("  [Press 'x' to Exit]");
    write_eeprom (address++, ch);
  } while(ch != 'x');
  
  for(i=0; i<address; i++) {
    ch = read_eeprom(i);
    printf("\r\nEEPROM Address[%lu] : ASCII: %c, Hex: %u", i, ch, ch);
  }
  
  while(1);   // Loop nothing
}
