/*--------------------------------------------------------
File      : EX1302.c
Purpose   : Port B any change on B4-B7
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877.h>          // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator

//-------------------------------------------------------:External Interrupt On Change B4-B7
#INT_RB
void IntRB_isr(void) {
   
   if (input(PIN_B4) == 0) output_toggle(PIN_D1);
      
   if (input(PIN_B5) == 0) output_toggle(PIN_D2);
      
   if (input(PIN_B6) == 0) output_toggle(PIN_D3);
      
   if (input(PIN_B7) == 0) output_toggle(PIN_D5);
   
  output_toggle(PIN_D6);
   delay_ms(100);      
}

//-------------------------------------------------------:MAIN
void main(void) {
   
   set_tris_d(0x00);                // Set PORTD output

   enable_interrupts(GLOBAL);       // Enable Glabal Interrupt 
   enable_interrupts(INT_RB);       // Enable Any change on B4-B7
   
   while(TRUE) {                    // loop forever
      output_toggle(PIN_D0);
      delay_ms(1000);      
   }
}
