/*--------------------------------------------------------
File      : EX1404.c
Purpose   : Demonstartes the watchdog timer
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,WDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)     // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

//-------------------------------------------------------:MAIN
void main(void)
{  
  int count;
  
  output_low(PIN_A0);
  
  // Program start
  for(count=0;count<20;count++)
  {
    output_toggle(PIN_A0);
    delay_ms(100);    
  }
  count = 0;
  
  switch( restart_cause() ) 
  {
    case WDT_TIMEOUT:
      printf("\r\nRestarted processor because of watchdog timeout!");
      break;
    case NORMAL_POWER_UP:
      printf("\r\nNormal power up!");
      break;
  }
  
  // WDT timeout 2.304 s
  setup_wdt(WDT_2304MS);

  while(TRUE) {
    if (count++ < 6)
    {    
      restart_wdt();
      printf("\r\nRestart watchdog :%d",count);
    }      
    output_toggle(PIN_A0);
    delay_ms(1000);
   }
}
