/*--------------------------------------------------------
File      : EX0202.c
Purpose   : Input/Output
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator

//-------------------------------------------------------:MAIN
void main(void)
{  
  set_tris_a(0xF0);      // Set PORTA for output    
  
  while(TRUE) {
   if(input(PIN_A4) == 0) { // Input switch Active Low 
    output_low(PIN_A0);
    output_high(PIN_A1);
   } else { 
    output_high(PIN_A0);    
    output_low(PIN_A1);    
   }  
  }
}
