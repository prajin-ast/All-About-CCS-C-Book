/*--------------------------------------------------------
File      : EX0703.c
Purpose   : String example
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:MAIN
void main(void) {
   char str[15];
   int i;

   printf("\r\nInput a string :");
   gets(str);
   
   for(i=0; i<15; i++)
   printf("%c",str[i]);
   
   puts("");               // new line & return
   printf("%s",str);            
   
   while(TRUE);
}
