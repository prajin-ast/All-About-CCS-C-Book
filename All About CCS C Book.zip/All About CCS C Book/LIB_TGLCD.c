/*
 ******************************************************************************
 * Workfile    : LIB_TGLCD.C
 * Purpose     : THAI GLCD128x64 Library
 * Author      : Prajin Palangsantikul
 * Copyright   : appsofttech co.,ltd.
 * WWW         : www.appsofttech.com
 * Compiler    : CCS C Compiler
 * Target      : PIC16F877A MCU
 * Ref         :
 * Date        : 09/05/2008
 ******************************************************************************
*/

#include <HDM64GS12.c>
#include <graphics.c>

#define SP_FONT  7         // Space font
#include "jfont8x16.h"     // Thai font 8x16

void TGLCD_putbitmap(char x, char y, unsigned char ascii);
void TGLCD_thaixy(char column, char row, unsigned char *content);

//*** Put bitmap
void TGLCD_putbitmap(char x, char y, unsigned char ascii)
{
   unsigned char bitmap[8] = { 0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01 };
   register char x1, y1;
   unsigned char map[16];

   if(ascii<16) memcpy(map, tfont1[ascii], 16);
   else if(ascii<32) memcpy(map, tfont2[ascii-16], 16);
   else if(ascii<48) memcpy(map, tfont3[ascii-32], 16);
   else if(ascii<64) memcpy(map, tfont4[ascii-48], 16);
   else if(ascii<80) memcpy(map, tfont5[ascii-64], 16);
   else if(ascii<96) memcpy(map, tfont6[ascii-80], 16);
   else if(ascii<112) memcpy(map, tfont7[ascii-96], 16);
   else if(ascii<128) memcpy(map, tfont8[ascii-112], 16);
   else if(ascii<144) memcpy(map, tfont9[ascii-128], 16);
   else if(ascii<160) memcpy(map, tfont10[ascii-144], 16);
   else if(ascii<176) memcpy(map, tfont11[ascii-160], 16);
   else if(ascii<192) memcpy(map, tfont12[ascii-176], 16);
   else if(ascii<208) memcpy(map, tfont13[ascii-192], 16);
   else if(ascii<224) memcpy(map, tfont14[ascii-208], 16);
   else if(ascii<240) memcpy(map, tfont15[ascii-224], 16);
   else memcpy(map, tfont16[ascii-240], 16);

   for( y1=0; y1<16; y1++) {
      for(x1=0; x1<8; x1++) {
         if( (map[y1] & bitmap[x1] ) != 0)
            GLCD_pixel((x+x1), (y+y1), 1);
      }
  }
}

//*** Thai X,Y
void TGLCD_thaixy(char column, char row, unsigned char *content)
{
   signed char k ,ypix, xpix;
   unsigned char asc;

//   column=(column-1)*8;
//   row=(row-1)*16;

   for(k=0; k<strlen(content); k++)
   {
      ypix=0; xpix=0;
      if(tolower(content[k]) > 160)
        asc = tolower(content[k]);
      else
        asc = content[k];
      if(asc==209) { xpix = -6; }
      if((asc>215) & (asc<219)) { xpix = -SP_FONT; }
      if((asc>211) & (asc<216)) { xpix = -SP_FONT; }
      if((asc>230) & (asc<239)) { ypix = +1; xpix = -SP_FONT; }

      TGLCD_putbitmap(column+xpix, row+ypix, asc);

      if(asc<209) column +=SP_FONT;
      if((asc>209) & (asc<212)) column +=SP_FONT;
      if((asc>223) & (asc<231)) column +=SP_FONT;
      if((asc>239) & (asc<250)) column +=SP_FONT;
   }
}
