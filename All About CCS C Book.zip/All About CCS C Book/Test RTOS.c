/*--------------------------------------------------------
File      : EX2102.c
Purpose   : CCS RTOS Demo (two)
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

// The CCS Real Time Operating System (RTOS) 
// the minor cycle fo all tasks will be 10 microseconds
#use rtos(timer=1,minor_cycle=10us)
//#use rtos(timer=1)

unsigned int16 task1, task2, task3;


//-------------------------------------------------------:TASK 1,2,3
#task(rate=10us,max=10us)
void rtos_task_1 ( )
{
  task1++;
}

#task(rate=50us,max=5us)
void rtos_task_2 ( )
{
  task2++;
}

#task(rate=100us,max=1us)
void rtos_task_3 ( )
{  
  task3++;
}

#task(rate=10us,max=10us)
void rtos_task_4 ( )
{
  printf("\r\n->Task1 %lu , Task2 %lu , Task3 %lu  "task1, task2, task3);
}

//-------------------------------------------------------:MAIN
// main is still the entry point for the program
void main ( )
{
  task1 = 0;
  task2 = 0;
  task3 = 0;
  // rtos_run begins the loop which will call the task functions above at the
  // schedualed time
  rtos_run ();
}

