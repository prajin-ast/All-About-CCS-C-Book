/*--------------------------------------------------------
File      : EX0301.c
Purpose   : PIC C Programming Example
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

#define PI 3.1416               // Constant variable
#define SQUARE(x) ((x) * (x))   // Macro Processing

//-------------------------------------------------------:Global variables
float area;

//-------------------------------------------------------:Functions prototypes
float Circle(float radius);

//-------------------------------------------------------:Function Circle
// Description : calc circle
float Circle(float radius) {
  float cir;                        // local Declarations
  cir = 4.0 * PI * SQUARE(radius);  // Expressions
  return(cir);                      // return function
}

//-------------------------------------------------------:MAIN
void main(void) 
{
   int radius = 3;   // Definitions
   
   area = Circle(radius);  // call Circle()
   
   // print output
   printf("Circle Area is %6.4f \n\r", area);   
   
   while(TRUE);      // loop nothing
}

