/*-----------------------------------------
File      : TEST.c
Purpose   : Test code program
Compiler  : CCS C Compiler
Target    : PIC16F877A
------------------------------------------*/

//----------------------------------------:INCLUDE
#include <16F877A.h>              // header file for PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)// standard output


void t1(void)
{
char const a[][3] = {{1,2,3},
                     {1,2,3},
                     };

}
//----------------------------------------:MAIN
void main(void) 
{   
   while(TRUE);      // loop nothing
}

