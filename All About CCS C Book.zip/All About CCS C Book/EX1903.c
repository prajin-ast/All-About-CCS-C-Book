/*--------------------------------------------------------
File      : EX1903.c
Purpose   : I2C CMPS03 (Digital Compass)
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // oscillator
#use I2C(master,sda=PIN_C4,scl=PIN_C3)  // I2C Bus module
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

/** Examples this is no test */

//-------------------------------------------------------:CONSTANTS
// CMPS03 Address
#define CMPS03_ID  0xC0  

//-------------------------------------------------------:MAIN
void main(void) {
  unsigned int version, unused, high, low;
   
  while(TRUE) {
    i2c_start();              // Send I2C Start Transfer
    i2c_write(CMPS03_ID);     // Send identifier I2C address - Write    
    i2c_write(0x00);          // Send register address
    
    i2c_start();              // Send I2C Repeated Start
    i2c_write(CMPS03_ID+1);   // Send identifier I2C address - Read
    
    version = i2c_read(1);    // Read data , ACK
    delay_ms(5);
    unused = i2c_read(1);     // Read data , ACK
    delay_ms(5);
    high = i2c_read(1);       // Read data , ACK
    delay_ms(5);
    low = i2c_read(0);        // Read data , Not ACK    
    i2c_stop();               // Send I2C Stop Transfer    
    printf("\r\nversion %u, unused %u, high %u, low %u",version, unused, high, low);
  }
}
