/*--------------------------------------------------------
File      : EX1601.c
Purpose   : Input Capture (CCP1)
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>          // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

#byte TRIS_C = 0x87           // TRISC File Address
#bit  RC2    = TRIS_C.2       // TRISC.2 bit address

BOOLEAN CCP_Hook = 0;

//-------------------------------------------------------:CCP1 Interrupt
#INT_CCP1
void CCP1_isr() {

  CCP_Hook = 1;
}

//-------------------------------------------------------:MAIN
void main(void) {
  int cpp_count = 1;
  
  set_tris_a(0x00);     // Set output
  RC2 = 1;              // Set input
  output_low(PIN_A0);   // Clear RA0
  
  enable_interrupts(INT_CCP1);    // Enable interrupt CCP1
  enable_interrupts(GLOBAL);      // All interrupts ON

  setup_ccp1(CCP_CAPTURE_DIV_16);   // Configure CCP1 to capture div 16
  setup_timer_1(T1_INTERNAL|T1_DIV_BY_8);   // Setup timer1
  set_timer1(0);                            // Start timer

  printf("\fCapture Mode");     // Clear screen & print
  
  while(TRUE) {  
    if (CCP_Hook)
    {
      printf("\r\nCCP1 %d : %lu",cpp_count,CCP_1);
      CCP_Hook = 0;   // Clear CCP hook
      if (cpp_count++>10) {
        cpp_count = 1;
        printf("\fCapture Mode");
      }
    }
    output_toggle(PIN_A0);
    delay_ms(100);
  }
}
