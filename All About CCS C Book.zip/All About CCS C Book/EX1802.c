/*--------------------------------------------------------
File      : EX1802.c
Purpose   : Analog Comparator module
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

//-------------------------------------------------------:MAIN
void main(void) {
   
  // Comparator Mode :Two Independent Comparators with outputs    
  setup_comparator(A0_A3_A1_A2_OUT_ON_A4_A5);
  
  while(TRUE) {    
    printf("\f\r\nAnalog Comparator module...");
    printf("\r\nMode:Two Independent Comparators with outputs");        
    printf("\r\nC1OUT : %d",C1OUT);
    if (C1OUT) {
      printf("\r\nA3 > A0, LED RA4 OFF");
    } else {
      printf("\r\nA3 < A0, LED RA4 ON");
    }
    printf("\r\nC2OUT : %d",C2OUT);
    if (C2OUT) {
      printf("\r\nA2 > A1, LED RA5 ON");
    } else {
      printf("\r\nA2 < A1, LED RA5 OFF");
    }
    delay_ms(500);
  }
}
