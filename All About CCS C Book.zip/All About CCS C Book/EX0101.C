/*--------------------------------------------------------
File      : EX0101.c
Purpose   : FLASH LED
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
---------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator

//-------------------------------------------------------:MAIN
void main(void)
{  
  set_tris_a(0x00);   // Set PORTA for output    
  
  while(TRUE) {
    output_low(PIN_A0);
    delay_ms(500);
    output_high(PIN_A0);
    delay_ms(500);
  }
}
