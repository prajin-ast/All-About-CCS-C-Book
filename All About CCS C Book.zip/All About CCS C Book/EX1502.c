/*--------------------------------------------------------
File      : EX1502.c
Purpose   : RS232 Interrupt Control
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>          // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

char digit;
BOOLEAN rx_int=FALSE;

//-------------------------------------------------------:RS232 Interrupt
#INT_RDA
void RS232_isr() {
  digit = getc();  
  rx_int= TRUE;
}

//-------------------------------------------------------:LED Control
void LedControl(unsigned int led) 
{
  unsigned int led_tmp=0;
  
  led_tmp = (1<<led);  // High LED
  output_d(led_tmp);   // output
}

//-------------------------------------------------------:MAIN
void main(void) {
  int i;

  set_tris_d(0x00);     // PORTB output
  set_tris_a(0x00);     // PORTA output
  output_d(0x00);       // clear led

  enable_interrupts(GLOBAL);    // enable interrupt global
  enable_interrupts(INT_RDA);   // enable interrupt rs232 receive data

  while(TRUE) {
    printf("\n\rInput 0-7 Number LED : ");
    while(!rx_int)
    {
      output_toggle(PIN_A0);
      delay_ms(1000);
    }      
    if (rx_int) {
      putc(digit);
      rx_int = FALSE;
      if(digit<'8') {
        i= digit-'0';
        LedControl(i);
      } else {
        puts(" (Invalid Number)");
      }
    }      
  }
}
