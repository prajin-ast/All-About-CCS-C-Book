/*--------------------------------------------------------
File      : EX0803_v2.c
Purpose   : Pointer to array example
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:Global variables
int num[10] = {0,1,2,3,4,5,6,7,8,9};

//-------------------------------------------------------:MAIN
void main(void) {
   int *iptr, i;

   iptr = num;

   for(i=0; i<10; i++)
  printf("%d ", iptr[i]);

   while(TRUE);
}
