/*--------------------------------------------------------
File      : EX1901.c
Purpose   : NOKIA LCD 5110
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // oscillator

#include "LIB_GLCD5110.C"         // NOKIA LCD 5110

//-------------------------------------------------------:MAIN
void main(void) {

  GLCD5110Init();
    
  GLCD5110GotoXY(25,0);
  GLCD5110PutStr("All PIC");
  GLCD5110GotoXY(7,2);
  GLCD5110PutStr("PIC C With CCS");
  GLCD5110GotoXY(7,4);
  GLCD5110PutStr("NOKIA LCD 5110");
      
  while(TRUE);    // Loop nothing
}
