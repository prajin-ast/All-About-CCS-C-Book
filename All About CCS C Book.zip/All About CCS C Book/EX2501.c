/*--------------------------------------------------------
File      : EX2501.c
Purpose   : Thai Display GLCD128x64
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // oscillator

#include <ctype.h>
#include <string.h>
#include <stdlib.h>

#include <HDM64GS12.c>        // use module GLCD function
#include <graphics.c>
#include "LIB_TGLCD.c"        // use module Thai GLCD function

void main(void)
{  
  char tstr1[16] = "All About CCS C";
  char tstr2[19] = "�����¹������Ѻ";
  char tstr3[19] = ">> PIC MCU <<";
  char tstr4[24] = "���� CCS C Compiler";
  
  glcd_init(ON);                // Must initialize the GLCD
  glcd_fillScreen(ON);
  delay_ms(1000);
  glcd_fillScreen(OFF);
  
  TGLCD_thaixy(10, 1, tstr1);
  TGLCD_thaixy(11, 1, tstr1);
  TGLCD_thaixy(7, 15, tstr2);
  TGLCD_thaixy(20, 30, tstr3);
  TGLCD_thaixy(21, 30, tstr3);
  TGLCD_thaixy(2, 45, tstr4);
  
  while (TRUE);                  // Loop  nothing
 }
