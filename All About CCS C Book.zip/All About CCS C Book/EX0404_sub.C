/*--------------------------------------------------------
File      : EX0404_sub.c
Purpose   : Sub program
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

extern int ExtObjectID;     // Declarations in EX0403_main.c

//-------------------------------------------------------:Function
int createExtObject(void) 
{
   static int id=0;

   id = id + 1;
   ExtObjectID = id;
   return(id);
}
