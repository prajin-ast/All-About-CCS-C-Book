/*--------------------------------------------------------
File      : EX0901.c
Purpose   : PIC C Programming Example
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:Functions prototypes
void func01(void);
int func02(int x, int y);
void func03(int x, int y);
void func04(int *x, int *y);

//-------------------------------------------------------:MAIN
void main (void) {
   int i,j,k;
    
   i = 10;
   j = 20;
    
   func01();  
   k = func02(i, j);
   printf("k = %d",k);
    
   printf("pass by value\n\r");
   printf("before in..func03 i=%d , j=%d\n\r",i,j);
   func03(i, j);
   printf("after  in..func03 i=%d , j=%d\n\r",i,j);
    
   printf("\npass by reference\n\r");
   printf("before in..func04 i=%d , j=%d\n\r",i,j);
   func04(&i, &j);
   printf("after  in..func04 i=%d , j=%d\n\r",i,j);

   while(TRUE);
}

//-------------------------------------------------------:Sub function
void func01(void) {
    printf("in..func01\n\r");
}

int func02(int x, int y) { 
    int z;
    
    z = x+y;
    printf("in..func02 %d\n\r",z);
    return(z);
}

void func03(int x, int y) { 
    int z;
    
    z = 10;
    x = x + z;
    y = y + z;
    printf("in..func03 x=%d , y=%d\n\r",x,y);
 }

void func04(int *x, int *y) {
    int z;
    
    z = 10;
    *x = *x + z;
    *y = *y + z;
    printf("in..func04 x=%d , y=%d\n\r",*x,*y);
}
