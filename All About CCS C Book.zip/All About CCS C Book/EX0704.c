/*--------------------------------------------------------
File      : EX0704.c
Purpose   : Two-Dimensional Strings example
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:MAIN
void main(void) {
   char str[5][15];
   int i;

   for(i=0; i<5; i++) {
      printf("\r\nInput a string :");
      gets(str[i]);
      puts(str[i]);
   }

   puts("");
   for(i=0; i<5; i++) {
      puts(str[i]);
      puts("");
   }
   
   while(TRUE);
}
