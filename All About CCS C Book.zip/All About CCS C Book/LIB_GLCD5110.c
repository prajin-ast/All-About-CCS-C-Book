/*
 ******************************************************************************
 * Workfile    : LIB_GLCD5110.C
 * Purpose     : NOKIA LCD 5110 Library
 * Author      : Prajin Palangsantikul
 * Copyright   : appsofttech co.,ltd.
 * WWW         : www.appsofttech.com 
 * Compiler    : CCS C Compiler
 * Target      : PIC16F877A MCU
 * Ref         :
 * Date        : 09/05/2008
 ******************************************************************************
*/

/*** Define PIN GLCD 5110 */
#define GLCD_SDIN     PIN_C5      // RC5/SDO -> GLCD SDIN
#define GLCD_SCLK     PIN_C3      // RC3/SCK -> GLCD SCLK

#define GLCD_SCE      PIN_D7      // GLCD Chip enable
#define GLCD_LED      PIN_D6      // GLCD Back Light
#define GLCD_DC       PIN_D5      // GLCD Data/Command
#define GLCD_RESET    PIN_D4      // GLCD Reset

#define GLCD_X_RES  84
#define GLCD_Y_RES  48

#define GLCD_SIZE  ((GLCD_X_RES * GLCD_Y_RES) / 8)

#include "font5x7.h"

typedef unsigned int U_INT8;

void GLCD5110Init(void);
void GLCD5110Clear(void);
void GLCD5110Reset(void);
void GLCD5110GotoXY(U_INT8 x, U_INT8 y);
void GLCD5110PutStr(U_INT8 ch);

// GLCD Enable/Disable
#define GLCD5110_ENABLE     output_low(GLCD_SCE);    
#define GLCD5110_DISABLE    output_High(GLCD_SCE);   
// write command/Data
#define GLCD5110_COMMAND    output_low(GLCD_DC);     
#define GLCD5110_DATA       output_High(GLCD_DC);    
// GLCD Back Light ON/OFF
#define GLCD5110_BK_ON      output_high(GLCD_LED);   
#define GLCD5110_BK_OFF     output_low(GLCD_LED);

/*
 ******************************************************************************
 * PROTOTYPE FUNCTION
 ******************************************************************************
*/

/*** Initialize GLCD */
void GLCD5110Init(void)
{  
  set_tris_C(0x00);         // Set PORTC output
  set_tris_d(0x0F);         // Set D4-D7 output
  // Setup SPI mode
  setup_spi(SPI_MASTER|SPI_L_TO_H|SPI_XMIT_L_TO_H|SPI_CLK_DIV_64);
  
  GLCD5110_BK_ON;          // GLCD Back Light On

  GLCD5110Reset();  
  
  GLCD5110_ENABLE;
  GLCD5110_COMMAND;
  spi_write(0x21);         // Initial LCD Command
  spi_write(0xC8);
  spi_write(0x06);  
  spi_write(0x13);
  spi_write(0x20);
  spi_write(0x0C);  
  GLCD5110_DISABLE;
  
  GLCD5110Clear();          // GLCD Clear Screen
}
/*** Clear Screen */
void GLCD5110Clear(void)
{
  int16 i;
  
  GLCD5110_ENABLE;
  GLCD5110_DATA;

  for (i=0;i<GLCD_SIZE;i++) {
    spi_write(0x00);
  }
  GLCD5110_DISABLE;
}

/*** Reset */
void GLCD5110Reset(void)
{
  GLCD5110_ENABLE;
  output_low(GLCD_RESET);   // GLCD Reset
  delay_ms(1);
  output_high(GLCD_RESET);
  GLCD5110_DISABLE
}

/*** Goto X,Y */
void GLCD5110GotoXY(U_INT8 x, U_INT8 y)
{
  GLCD5110_ENABLE;
  GLCD5110_COMMAND;
  spi_write((0x80)|x);     // X-AGLCDreLED = 0
  spi_write((0x40)|y);     // Y-AGLCDreLED = 0
  GLCD5110_DISABLE
}

/*** Put String */
void GLCD5110PutStr(U_INT8 ch)
{
  unsigned int16 ascii;
  unsigned char map[5];
  
  GLCD5110_ENABLE;
  GLCD5110_DATA;
  
  ascii = ch-32;        // Position ASCII FONT
  
  if(ascii<51) 
    memcpy(map, FONT[ascii], 5);
  else {
    ascii = ascii-51;   // Position ASCII FONT2
    memcpy(map, FONT2[ascii], 5);  
  } 
  
  for (ch=0;ch<5;ch++) { 
    spi_write(map[ch]); // Write FONT5x7
  }
  
  GLCD5110_DISABLE;
}
