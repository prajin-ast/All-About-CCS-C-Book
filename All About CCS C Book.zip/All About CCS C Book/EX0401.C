/*--------------------------------------------------------
File      : EX0401.c
Purpose   : sizeof() function
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:MAIN
void main(void) {
   int1 i1; int8 i8; int16 i16;  int32 i32;
   char ch;
   float f;
   short s;
   int i;
   long l;

   printf("Determines size in byte of data type\n\r");
   printf("Size of int1  %d bit \n\r",sizeof(i1));
   printf("Size of int8  %d byte\n\r",sizeof(i8));
   printf("Size of int16 %d byte\n\r",sizeof(i16));
   printf("Size of int32 %d byte\n\r",sizeof(i32));
   printf("Size of char  %d byte\n\r",sizeof(ch));
   printf("Size of float %d byte\n\r",sizeof(f));
   printf("Size of short %d bit\n\r",sizeof(s));
   printf("Size of int   %d byte\n\r",sizeof(i));
   printf("Size of long  %d byte\n\r",sizeof(l));

   while(TRUE);
}

