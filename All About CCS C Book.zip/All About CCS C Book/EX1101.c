/*--------------------------------------------------------
File      : EX1101.c
Purpose   : inline asm in C
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:Function find_parity
int find_parity (int data)    {
   int count;

   #asm
      movlw   0x8
      movwf   count
      movlw   0
      loop:
      xorwf   data,w
      rrf     data,f
      decfsz  count,f
      goto    loop
      movwf   _return_
   #endasm
}

//-------------------------------------------------------:MAIN
void main(void) {
   byte p, d=7;

   p = find_parity(d);
   printf("%x",p);

   while(TRUE);
}
