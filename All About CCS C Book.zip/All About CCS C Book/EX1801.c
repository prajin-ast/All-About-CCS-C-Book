/*--------------------------------------------------------
File      : EX1801.c
Purpose   : Analog Comparator module
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

//-------------------------------------------------------:MAIN
void main(void) {
   
  // Comparator Mode :Two Independent Comparators   
  setup_comparator(A0_A3_A1_A2);
  
  while(TRUE) {    
    printf("\f\r\nAnalog Comparator module...");
    printf("\r\nMode:Two Independent Comparators");        
    printf("\r\nC1OUT : %d",C1OUT);
    if (C1OUT) {
      printf("\r\nA3 > A0");
    } else {
      printf("\r\nA3 < A0");
    }
    printf("\r\nC2OUT : %d",C2OUT);
    if (C2OUT) {
      printf("\r\nA2 > A1");
    } else {
      printf("\r\nA2 < A1");
    }
    delay_ms(500);
  }
}
