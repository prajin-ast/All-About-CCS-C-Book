/*--------------------------------------------------------
File      : EX2401.c
Purpose   : LCD 16x2 and 1-wire bus
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // oscillator

#include "lcd.c"              // use module lcd function
#include "touch.c"            // use module 1-wire bus function

//-------------------------------------------------------:LCD PINs
// Driver for common LCD modules As defined in the following 
// structure the pin connection is as follows:
// RD0 = E(enable), RD1 = RS, RD2 = R/W
// RD4 = RD4, RD5 = D5, RD6 = D6, RD7 = D7
// LCD pins D0-D3 are not used and PIC RD3 is not used

//-------------------------------------------------------:1-Wire PIN
// PIN B0 for 1-Wire bus


//-------------------------------------------------------:ReadTemp_DS18B20
// Read Temperature (use RB0 read temp)
BYTE ReadTemp_DS18B20(void)
{
  BYTE i, buffer[9];
  BYTE temp,sign;

  if (touch_present()) {       // get present (reset)
    touch_write_byte(0xCC);    // Skip ROM
    touch_write_byte (0x44);   // Start Conversion
    delay_ms(100);             // delay 200 ms
    touch_present();           // get present (reset)
    touch_write_byte(0xCC);    // Skip ROM
    touch_write_byte (0xBE);   // Read Scratch Pad

    for(i=0; i<9;i++)          // read 9 bytes
      buffer[i] = touch_read_byte();
  }

  temp = (buffer[1]<<4)|(buffer[0]>>4);       // Temperature
  if(buffer[1]&0xF0) temp = (-1)*temp;        // Sign bit

  return(temp);
}

//-------------------------------------------------------:MAIN
void main(void) {
  BYTE DS18B20_temp;
  
  lcd_init();       // LCD initialize
  
  while(TRUE){
    DS18B20_temp = ReadTemp_DS18B20();  
    lcd_putc("\f");
    lcd_gotoxy(1,1);
    lcd_putc("DS18B20 (LCD-1W)");
    lcd_gotoxy(1,2);
    printf(lcd_putc,"Temp : %d %cC",DS18B20_temp,0xDF);
    delay_ms(1000);
  }
}


