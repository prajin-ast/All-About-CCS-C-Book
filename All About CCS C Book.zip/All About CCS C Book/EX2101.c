/*--------------------------------------------------------
File      : EX2101.c
Purpose   : CCS RTOS Demo (one)
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

// The CCS Real Time Operating System (RTOS) 
// the minor cycle for all tasks will be 50 miliseconds
#use rtos(timer=1,minor_cycle=50ms)

unsigned int16 task1, task2, task3;

//-------------------------------------------------------:TASK 1,2,3
#task(rate=100ms,max=50ms)
void rtos_task_1 ( )
{
  task1++;
  output_toggle(PIN_A0);
}

#task(rate=500ms,max=50ms)
void rtos_task_2 ( )
{
  task2++;
  output_toggle(PIN_A1);
}

#task(rate=1000ms,max=50ms)
void rtos_task_3 ( )
{
  static char port_l=1;
  
  task3++;
  rotate_left(&port_l, 1);
  output_d(port_l);
}

#task(rate=50ms,max=50ms)
void rtos_task_4 ( )
{ 
  printf("\n\r->Task1 %lu , Task2 %lu , Task3 %lu  "task1, task2, task3);
}

//-------------------------------------------------------:MAIN
// main is still the entry point for the program
void main ( )
{
  // Set PORTA,PORTD output
  set_tris_a(0);
  set_tris_d(0);
  // Clear port
  output_a(0);
  output_d(0);
  
  task1 = 0;
  task2 = 0;
  task3 = 0;
  
  printf("\f4 Task Demo");
  // rtos_run begins the loop which will call the task functions above at the
  // schedualed time
  rtos_run ();
}

