/*--------------------------------------------------------
File      : EX1701.c
Purpose   : Using port A to anolog input port
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#device ADC=10                   // 10bit A/D
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

//-------------------------------------------------------:MAIN
void main(void) {
  int16 value;

  printf("Analog to digital port RA0 :");
  setup_port_a(AN0_AN1_AN2_AN3_AN4);   // A0 A1 A2 A3 A5
  setup_adc(ADC_CLOCK_DIV_32);         // 32Tosc Operation
  set_adc_channel(0);                  // Read Analog input RA0(channel=0)

  do {
    value = read_adc();               // Read ADC
    printf("\f\nADC : %ld Voltage : %f",value, value*(5.0/1023));
    delay_ms(1000);
  } while (TRUE);
}
