/*--------------------------------------------------------
File      : EX2301.c
Purpose   : Keypad
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // oscillator

#define use_portb_kbd         // define for use portb kbd
#include "KBD.C"              // use module function

#define LED_DSP(x)   OUTPUT_D(x)

// The black keypad layout
// COL0 : RB5 , COL1 : RB6
// COL2 : RB7
// ROW0 : RB1 , ROW1 : RB2
// ROW2 : RB3 , ROW3 : RB4

//-------------------------------------------------------:GLOBAL VARIABLES
char dt1,dt2;        // delay time

// LED Number for keypad
char const  LED_NUM[17] = {0x06, 0x5B, 0x4F,  //1,2,3
                           0x66, 0x6D, 0x7D,  //4,5,6
                           0x07, 0x7F, 0x6F,  //7,8,9
                           0x63, 0x3F, 0x76,  //*,0,#
                          };
                     
//-------------------------------------------------------:Dispaly Digit1
void dsp_digit1(char n) {
  output_a(0x06);
  LED_DSP(n);
  delay_ms(3-dt1-dt2);   // delay
}

//-------------------------------------------------------:Dispaly Digit1
void dsp_digit2(char n) {
  output_a(0x05);
  LED_DSP(n);
  delay_ms(dt1);        // delay
}

//-------------------------------------------------------:Dispaly Digit1
void dsp_digit3(char n) {
  output_a(0x03);
  LED_DSP(n);
  delay_ms(dt2);        // delay
}

//-------------------------------------------------------:ATOC
// Converts the char to int
int atoc(char c) {
  int i;

  i = c -'1';
  if(c=='*') i = 9;
  if(c=='0') i = 10;
  if(c=='#') i = 11;

  return(i);
}

//-------------------------------------------------------:MAIN
void main(void) {
  int i, c1,c2,c3;
  char ch;

  // Pullups PORTB for scankey
  port_b_pullups(true);

  set_tris_a(0x00);    // Set PORTA output
  set_tris_d(0x00);    // Set PORTD output

  dt1 = 1;
  dt2 = 1;

  i = 0;
  output_a(0x07);     // Off digit

  while(TRUE) {
    ch = kbd_getc();
    if(ch!=0) {
      i++;
      if(i>2) {
        c3 = c2;
        i = 3;
      }
      if(i>1) c2 = c1;
        c1 = atoc(ch);
      }

      dsp_digit1(LED_NUM[c1]);
      if(i>1) dsp_digit2(LED_NUM[c2]);
      if(i>2) dsp_digit3(LED_NUM[c3]);
   }
}


