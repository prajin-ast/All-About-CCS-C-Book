/*--------------------------------------------------------
File      : EX0705.c
Purpose   : String function example
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

#include <string.h>              // Standard string functions Header file

//-------------------------------------------------------:MAIN
void main(void) {
   char string1[27], string2[4];
   char *ptr;

   strcpy(string1,"abcdefghijklmnopqrstuvwxyz");
   strcpy(string2,"omn");

   ptr = strpbrk(string1, string2);
   if(ptr) {
      printf("\r\nstrpbrk found first character: %c  ", *ptr);
   } else {
      printf("\r\nstrpbrk didn't find character in set  ");
   }
   
   while(TRUE);
}
