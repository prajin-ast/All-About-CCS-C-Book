/*--------------------------------------------------------
File      : EX1803.c
Purpose   : Analog Comparator & Reference Voltage module
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

//-------------------------------------------------------:MAIN
void main(void) {
  
  //Four Inputs Multiplexed to Two Comparators
  setup_comparator(A0_VR_A1_VR);
  // Vdd*(value/32)+Vdd/4 = 3.59375
  setup_vref(VREF_HIGH|15);           
  
  while(TRUE) {
    printf("\f\r\nAnalog Comparator module...");
    printf("\r\nMode:Four Inputs Multiplexed to Two Comparators");
    printf("\r\nVoltage Ref. is 3.6 V.");

    printf("\r\nC1OUT : %d",C1OUT);
    if (C1OUT) {
      printf("\r\nVref > A0");
    } else {
      printf("\r\nVref < A0");
    }
    printf("\r\nC2OUT : %d",C2OUT);
    if (C2OUT) {
      printf("\r\nVref > A1");
    } else {
      printf("\r\nVref < A1");
    }
    delay_ms(500);    
  }
}
