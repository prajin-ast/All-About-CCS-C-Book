/*--------------------------------------------------------
File      : EX0802.c
Purpose   : Pointer example
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>       // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output

//-------------------------------------------------------:MAIN
void main(void) {
   int i, j, *ptr;
   
   i = 10;
   j =  20;
   ptr = &i;   
   printf("i = %d, j = %d, *ptr = %d\n\r",i, j, *ptr);
   
   while(TRUE);
}
