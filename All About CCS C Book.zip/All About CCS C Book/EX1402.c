/*--------------------------------------------------------
File      : EX1402.c
Purpose   : Digital Clock Timer1
Author    : Prajin Palangsantikul
WWW       : www.appsofttech.com
Compiler  : CCS C Compiler
Target    : PIC16F877A
--------------------------------------------------------*/

//-------------------------------------------------------:INCLUDE
#include <16F877A.h>         // Standard Header file for the PIC16F877A
#fuses HS,NOWDT,NOPROTECT,NOLVP  // Configuration word
#use delay(clock=20000000)       // oscillator
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

struct time{
   int sec;     // seconds
   int min;     // minute
   int hr;      // hour      
}tmr1;

int int_count = 0;      // Number of interrupts left before a second has elapsed

//-------------------------------------------------------:Timer0 Interrupt
// This function is called every time the RTCC (timer0) overflows (255->0).
// For this program this is apx 76 times per second.
#INT_TIMER1
void clock_isr() {
  if(int_count++ >9) {
    if (++tmr1.sec == 60) {
      tmr1.sec = 0;
      if (tmr1.min++ == 60) {
        tmr1.min = 0;
        if(tmr1.hr++ == 24)
          tmr1.hr = 0;
        }
      }
    int_count = 0;
  }
}

//-------------------------------------------------------:MAIN
void main() {
   
  enable_interrupts(GLOBAL);
  enable_interrupts(INT_TIMER1);

  setup_timer_1(T1_INTERNAL|T1_DIV_BY_8);
  set_timer1(0);
  
  tmr1.sec = 0;
  tmr1.min = 59;
  tmr1.hr  = 9;

  do {
     if(int_count == 0) {
        printf("\f\r Time ");
        (tmr1.hr<10) ? printf("0%d:",tmr1.hr) : printf("%d:",tmr1.hr);         
        (tmr1.min<10)? printf("0%d:",tmr1.min): printf("%d:",tmr1.min);
        (tmr1.sec<10)? printf("0%d",tmr1.sec) : printf("%d",tmr1.sec);         
     }         
  } while (TRUE);
}
